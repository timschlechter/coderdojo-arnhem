var state = {
    preload: function () {
    },

    create: function () {
    },

    update: function () {
    }
}

withPipes(state);

var game = new Phaser.Game(window.innerWidth, window.innerHeight, Phaser.CANVAS);
game.state.add('main', state);
game.state.start('main');
